<?php

function charity_vc_cause_latest_donors($atts, $content = null) {
    get_template_part("content/home/home", "five-causes");
}
