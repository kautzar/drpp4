<?php 

return array(
      "name"              => __("Donate Now", "charity"),
      "base"              => "donate_now",
      "class"             => "",
      "icon"              => "icon-charity",
      "description"       => "Add donote now button",
      "category"          => __('Charity Shortcodes', "charity"),
      "params"            => array()
   );
