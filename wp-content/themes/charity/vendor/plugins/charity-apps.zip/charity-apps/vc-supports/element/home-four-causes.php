<?php

return array(
    "name" => __("Causes Donors List", "charity"),
    "base" => "causes_donors_list",
    "class" => "",
    "icon" => "icon-charity",
    "description" => "Donate and See Donors",
    "category" => __('Charity Shortcodes', "charity"),
    "params" => array()
);
