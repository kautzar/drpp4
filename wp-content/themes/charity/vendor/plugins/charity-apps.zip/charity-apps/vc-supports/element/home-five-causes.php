<?php

return array(
    "name" => __("Causes Latest Donors", "charity"),
    "base" => "cause_latest_donors",
    "class" => "",
    "icon" => "icon-charity",
    "description" => "Donate and Join and See latest Donors",
    "category" => __('Charity Shortcodes', "charity"),
    "params" => array()
);
