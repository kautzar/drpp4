<?php 
//DEPRECATED, MODIFY THE INCLUDED TEMPLATE INSTEAD
include('event/bookings-ticket-form.php');  	